package com.example.chirpio;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<Posts> postlist;
    public PostAdapter(ArrayList<Posts>list){
        postlist=list;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View v=inflater.inflate(R.layout.recvu_row_postlist,parent,false);
        MyViewHolder mvh=new MyViewHolder(v);
        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MyViewHolder mvh=(MyViewHolder)holder;
        Posts p=postlist.get(position);
        mvh.tv1.setText(p.getName());
        mvh.tv2.setText(p.getDate());
        mvh.tv3.setText(p.getPost());
        mvh.tv4.setText(String.valueOf(p.getLike_count()));
        mvh.tv5.setText(String.valueOf(p.getComment_count()));

    }

    @Override
    public int getItemCount() {
        return postlist.size();
    }
    class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView tv1,tv2,tv3,tv4,tv5;
        public  MyViewHolder(@NonNull View itemview){
            super(itemview);
            tv1=itemview.findViewById(R.id.tv_recvu_username);
            tv2=itemview.findViewById(R.id.tv_recvu_date);
            tv3=itemview.findViewById(R.id.tv_recvu_thought);
            tv4=itemview.findViewById(R.id.tv_recvu_likecount);
            tv5=itemview.findViewById(R.id.tv_recvu_commentcount);

        }

    }
}
