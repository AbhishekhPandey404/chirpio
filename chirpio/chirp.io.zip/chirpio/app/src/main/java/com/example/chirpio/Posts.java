package com.example.chirpio;

import com.google.firebase.firestore.Blob;

import java.io.Serializable;

public class Posts implements Serializable {
    private String name,post,date;
    private Blob comment_count;
    private int like_count;

    public Posts(String n, String d, String p, int l, int c) {
    }

    public Posts(String name, String post, String date, Blob comment_count, int like_count) {
        this.name = name;
        this.post = post;
        this.date = date;
        this.comment_count = comment_count;
        this.like_count = like_count;
    }

    public String getName() {
        return name;
    }

    public String getPost() {
        return post;
    }

    public String getDate() {
        return date;
    }

    public Blob getComment_count() {
        return comment_count;
    }

    public int getLike_count() {
        return like_count;
    }
}


